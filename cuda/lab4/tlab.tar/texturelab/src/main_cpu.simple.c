#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

#define NSZ 100

typedef struct {
	uint32_t y;
	uint32_t x;
} point;

typedef struct {
	uint8_t r;
	uint8_t g;
	uint8_t b;
	uint8_t a;
} color;

double   origc(uint32_t coord, uint32_t olddim, uint32_t newdim);
point    origp(point p, point od, point nd);
//point    newp (point p, point od, point nd);
uint32_t space(point p);
color    get_pixel(uint32_t *data, point dim, point dot);
color    set_pixel(uint32_t *data, point dim, point dot, color val);
color    interpol (uint32_t *data, point  od, point  nd, point npos);
color    inter_4point(double lco, color lpixcol, color rpixcol);
point    newp(int64_t y, int64_t x, point dim);

inline point newp(int64_t y, int64_t x, point dim) {
	point p;

	p.y = MAX(0, MIN(y, dim.y));
	p.x = MAX(0, MIN(x, dim.x));

	return p;
}

inline point origp(point p, point od, point nd) {
	point rp = { origc(p.y, od.y, nd.y), origc(p.x, od.x, nd.x) };

	return rp;
}

inline uint32_t space(point p) {
	return p.x * p.y;
}

int read_data(char *name, point *dim, uint32_t **data) {
	int res = 0;

	fprintf(stderr, "%s\n", name);

	if (name && dim && data) {
		FILE *dfile = fopen(name, "rb");

		if (dfile) {
			fread(&(dim->x), sizeof(dim->x), 1, dfile);
			fread(&(dim->y), sizeof(dim->y), 1, dfile);

			*data = (uint32_t *)malloc(sizeof(uint32_t) * space(*dim));

			fread(*data, sizeof(*data), space(*dim), dfile);

			fclose(dfile);
		}
		else
			res = 2;
	}
	else
		res = 1;

	return res;
}

inline color get_pixel(uint32_t *data, point dim, point dot) {
	color c;
	uint32_t y = dot.y;
	uint32_t x = dot.x;

	if (y >= dim.y)
		y = dim.y - 1;
	
	if (x >= dim.x)
		x = dim.x - 1;
	
	memcpy(&c, data + dim.x * y + x, sizeof(*data));

	return c;
}

inline color set_pixel(
	uint32_t *data, 
	point dim,
	point dot,
	color val
) {
	uint32_t y = dot.y;
	uint32_t x = dot.x;

	if (y >= dim.y)
		y = dim.y - 1;
	
	if (x >= dim.x)
		x = dim.x - 1;
	
	memcpy(data + dim.x * y + x, &val, sizeof(*data));
//	return data[dim.x * dot.y + dot.x] = val;

	return val;
}

inline double origc(uint32_t coord, uint32_t olddim, uint32_t newdim) {
	//return ((double)coord * olddim) / newdim;
	return (coord + 0.5) * olddim / (double)newdim - 0.5;
}

color sum(color lp, color rp) {
	color res = { lp.r + rp.r, lp.g + rp.g, lp.b + rp.b };

	return res;
}

double calc_lco(double precise_coord, uint32_t size) {
	//~ double percent = precise_coord / size;
	
	//~ return percent - (uint32_t)floor(percent);

	return precise_coord - floor(precise_coord);
}

inline color inter_4point(double lco, color lpixcol, color rpixcol) {
	color  c;
	double rco = 1 - lco;

	//~ printf("%g * %u = %g\n", rco, lpixcol.r, lpixcol.r * rco);
	//~ printf("%g * %u = %g\n", lco, rpixcol.r, rpixcol.r * lco);

	c.r = lpixcol.r * rco + rpixcol.r * lco;
	c.g = lpixcol.g * rco + rpixcol.g * lco;
	c.b = lpixcol.b * rco +	rpixcol.b * lco;

	//~ printf("sum = %u\n", c.r);

	return c;
}

color interpol(uint32_t *data, point od, point nd, point npos) {
	color    c[3];
	double   oy_prec   = origc(npos.y, od.y, nd.y);
	double   ox_prec   = origc(npos.x, od.x, nd.x);
	point    opoint[2];
	double   lco;

	lco = calc_lco(ox_prec, od.x);

	printf("Orig. position: (%g, %g)\n", oy_prec, ox_prec);

	opoint[0] = newp(oy_prec,      ox_prec,         od);
	opoint[1] = newp(opoint[0].y,  opoint[0].x + 1, od);

	//~ printf("Orig0: (%u, %u) of %u\n", opoint[0].y, opoint[0].x, get_pixel(data, od, opoint[0]).r);
	//~ printf("Orig1: (%u, %u) of %u\n", opoint[1].y, opoint[1].x, get_pixel(data, od, opoint[0]).r);
	
	c[0] = inter_4point(
		lco,
		get_pixel(data, od, opoint[0]),
		get_pixel(data, od, opoint[1])
	);

	//lco = calc_lco(ox_prec, od.x);

	opoint[0] = newp(opoint[0].y + 1, ox_prec,         od);
	opoint[1] = newp(opoint[0].y,     opoint[0].x + 1, od);

	//~ printf("Orig0: (%u, %u) of %u\n", opoint[0].y, opoint[0].x, get_pixel(data, od, opoint[0]).r);
	//~ printf("Orig1: (%u, %u) of %u\n", opoint[1].y, opoint[1].x, get_pixel(data, od, opoint[0]).r);
	
	c[1] = inter_4point(
		lco,
		get_pixel(data, od, opoint[0]),
		get_pixel(data, od, opoint[1])
	);
	
	lco = calc_lco(oy_prec, od.y);
	
	c[2] = inter_4point(
		lco,
		c[0],
		c[1]
	);

	//~ printf("\n\n\n");

	return c[2];
}

void process_n4o(
	uint32_t *data, point od,
	uint32_t *nimg, point nd
) {
	uint32_t y, x;

	for (y = 0; y < nd.y; ++y)
		for (x = 0; x < nd.x; ++x) {
			color  pix;

			//pix = get_pixel(data, od, (point){oy, ox});
			pix = interpol(data, od, nd, (point){y, x});

			set_pixel(nimg, nd, (point){y, x}, pix);
		}

	return;
}

//~ void process_o2n(
	//~ uint32_t *data, point od,
	//~ uint32_t *nimg, point nd
//~ ) {
	//~ uint32_t y, x;

	//~ for (y = 0; y < od.y; ++y)
		//~ for (x = 0; x < od.x; ++x) {
			//~ point p   = {y, x};
			//~ point np  = newp(p, od, nd);
			//~ color pix = { 0 };

			//~ size_t r = 0, g = 0, b = 0;

			//~ for (int sy = -1; sy <= 1; ++sy)
				//~ for (int sx = -1; sx <= 1; ++sx) {
					//~ color tmp = get_pixel(data, od, (point){y + sy, x + sx});

					//~ r += tmp.r;
					//~ g += tmp.g;
					//~ b += tmp.b;
				//~ }

			//~ //size_t l = (0.3 * r + 0.586 * g + 0.114 * b) / 9;

			//~ pix.r = r / 9;
			//~ pix.g = g / 9;
			//~ pix.b = b / 9;

			//~ set_pixel(nimg, nd, np, pix);
		//~ }

	//~ return;
//~ }

int write_data(char *onm, uint32_t *data, point dim) {
	int res = 0;

	if (data && onm) {
		FILE *dfile = fopen(onm, "wb");
		uint32_t nw = dim.x;
		uint32_t nh = dim.y;

		if (dfile) {
			fwrite(&nw,   sizeof( dim.x),         1, dfile);
			fwrite(&nh,   sizeof( dim.y),         1, dfile);
			fwrite( data, sizeof(*data), space(dim), dfile);

			fclose(dfile);
		}
		else
			res = 2;
	}
	else
		res = 1;

	return res;
}

int main(void) {
	point     olddim;
	point     newdim;
	uint32_t *data = NULL;
	char      inname[NSZ], ouname[NSZ];
	int       res;
	
	fgets(inname, NSZ, stdin);
	fgets(ouname, NSZ, stdin);

	inname[strcspn(inname, "\n")] = '\0';
	ouname[strcspn(ouname, "\n")] = '\0';

	scanf("%u", &(newdim.x));
	scanf("%u", &(newdim.y));

	res = read_data(inname, &olddim, &data);

	if (res)
		fprintf(stderr, "Error-in : %d\n", res);
	else {
		uint32_t *nimg = (uint32_t *)malloc(sizeof(uint32_t) * space(newdim));

		fprintf(stderr, "size = %ux%u\n", olddim.x, olddim.y);

		if (data) {
			if (nimg) {
				process_n4o(data, olddim, nimg, newdim);

				if ((res = write_data(ouname, nimg, newdim)))
					fprintf(stderr, "Error-out: %d\n", res);

				free(nimg);
			}
			free(data);
		}
	}

	return 0;
}
