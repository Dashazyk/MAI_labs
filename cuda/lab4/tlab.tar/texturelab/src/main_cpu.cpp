#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
	int r;
	int g;
	int b;
	int a;
} point;

void enblack(point *data, int w, int h) {
	int x, y;
	point p;
	
	for (y = 0; y < h; y++)
		for (x = 0; x < w; x++) {
			int br;
			
			p  = data[y * w + x];
			br = p.r * 0.299 + p.g * 0.587 + p.b * 0.114;
			//~ br = sqrt(p.x * p.x * 0.299 + p.y * p.y * 0.587 + p.z * p.z * 0.114);
			
			data[y * w + x].r = br;
			data[y * w + x].g = br;
			data[y * w + x].b = br;
			data[y * w + x].a = p.a;
		}
}


double get_ms() {
    struct timespec _t;
    clock_gettime(CLOCK_REALTIME, &_t);
    return _t.tv_sec*1000 + (_t.tv_nsec/1.0e6);
}

int main(int argc, char **argv) {
	int     w, h;
	int     err = 0;
	char   *inm = NULL;
	char   *onm = NULL;
	FILE   *finp;
	FILE   *fout;
	char    t1[100];
	char    t2[100];
	point *data;

	if (argc == 1) {
		scanf("%s", t1); 
		scanf("%s", t2);
			
		inm = t1;
		onm = t2;
	}
	else {
		inm = argv[1];
		onm = argv[2];
	}

	if (!err) {
		finp = fopen(inm, "rb");
		fout = fopen(onm, "wb");
	}

	if (finp) {
		fread(&w, sizeof(int), 1, finp);
		fread(&h, sizeof(int), 1, finp);
		
		fprintf(stderr, "%dx%d\n", w, h);
		
		data = (point *)malloc(sizeof(point) * w * h);
		
		if (data) {
			fprintf(stderr, "Reading data\n");
			fread  (data, sizeof(point), w * h, finp);
			fprintf(stderr, "Reading ok\n");

			fprintf(stderr, "Started\n");
			double start = get_ms();
			enblack(data, w, h);
			double end = get_ms();
			fprintf(stderr, "%g\n", end - start);
			fprintf(stderr, "Finished\n");
		}
		else
			err = 96;
	
		fclose(finp);
	}
	else
		err = 99;
	
	if (fout) {
		fprintf(stderr, "Writing data\n");

		fwrite(&w,   sizeof(int), 1, fout);
		fwrite(&h,   sizeof(int), 1, fout);
		fwrite(data, sizeof(point), w * h, fout);
		
		fclose(fout);
		free  (data);
		
		fprintf(stderr, "Data written\n");
	}
	else
		err = 98;
		
	if (err)
		fprintf(stderr, "E: error with code %d has occured!\n", err);
	
	return err;
}

