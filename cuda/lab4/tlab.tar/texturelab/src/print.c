#include <stdio.h>

typedef struct {
	int32_t y;
	int32_t x;
} point;

typedef struct {
	uint8_t r;
	uint8_t g;
	uint8_t b;
	uint8_t a;
} color;

inline color get_pixel(uint32_t *data, point dim, point dot) {
	color c;
	int32_t y = dot.y;
	int32_t x = dot.x;

	y = MAX(0, MIN(y, dim.y - 1));
	x = MAX(0, MIN(x, dim.x - 1));
	//~ if (y >= dim.y)
		//~ y = dim.y - 1;

	//~ if (x >= dim.x)
		//~ x = dim.x - 1;

	memcpy(&c, data + dim.x * y + x, sizeof(*data));

	return c;
}


int read_data(char *name, point *dim, uint32_t **data) {
	int res = 0;

	fprintf(stderr, "%s\n", name);

	if (name && dim && data) {
		FILE *dfile = fopen(name, "rb");

		if (dfile) {
			fread(&(dim->x), sizeof(dim->x), 1, dfile);
			fread(&(dim->y), sizeof(dim->y), 1, dfile);

			*data = (uint32_t *)malloc(sizeof(uint32_t) * space(*dim));

			fread(*data, sizeof(*data), space(*dim), dfile);

			fclose(dfile);
		}
		else
			res = 2;
	}
	else
		res = 1;

	return res;
}

int main(void) {
	
}
